clear;
clc;
close all;
tic;
%% ----------------------------------------------------���Գߴ�
tau=1/50;
T=100;
%% ----------------------------------------------------�����㷨
[g1_type1,g2_type1,relaxation_tau_type1,detB_type1,tk_type1,Iter_type1]=relaxation_factors_tau_B_N_compare_type1_1D(tau,T);
[g1_type2,g2_type2,relaxation_tau_type2,detB_type2,tk_type2,Iter_type2]=relaxation_factors_tau_B_N_compare_type2_1D(tau,T);

[g1_type1_MRRB3,g2_type1_MRRB3,relaxation_tau_type1_MRRB3,detB_type1_MRRB3,tk_type1_MRRB3,Iter_type1_MRRB3]...
    =MRRB3_relaxation_factors_tau_B_N_compare_type1_1D(tau,T);
[g1_type2_MRRB3,g2_type2_MRRB3,relaxation_tau_type2_MRRB3,detB_type2_MRRB3,tk_type2_MRRB3,Iter_type2_MRRB3]...
    =MRRB3_relaxation_factors_tau_B_N_compare_type1_1D(tau,T);
%% ----------------------------------------------------�����ɳ�ʱ�䲽�� 
figure(1);
plot(tk_type1,relaxation_tau_type1,'r-','LineWidth',1.5);
hold on;
plot(tk_type1_MRRB3,relaxation_tau_type1_MRRB3,'b-','LineWidth',1.5);
hold on;
plot(0:0.1:100,tau*ones(1,size(0:0.1:100,2)),'k:','LineWidth',2);
legend('$\mathrm{MRRB2}$ I','$\mathrm{MRRB3}$ I','$\tau=0.02$','interpreter','latex')
% set(gca,'YLim',[tau-0.002 tau+0.001])
set(gca,'YLim',[0.0196 0.0201])
set(gca,'LineWidth',1.5,'FontName','Times New Roman','FontSize',15,'FontWeight','bold');
xlabel('$\mathrm{Time}$','interpreter','latex','FontSize',25)
ylabel('$\tau_{\gamma}$','interpreter','latex','FontSize',25)
%���ƾֲ��Ŵ���ͼ
ax_zoom=axes('Position',[0.3, 0.3, 0.3, 0.25]);
plot(tk_type1,relaxation_tau_type1,'r-','LineWidth',1.5, 'Parent',ax_zoom);
hold on;
plot(tk_type1_MRRB3,relaxation_tau_type1_MRRB3,'b-','LineWidth',1.5, 'Parent',ax_zoom);
hold on;
plot(0:0.1:100,tau*ones(1,size(0:0.1:100,2)),'k:','LineWidth',2, 'Parent',ax_zoom);hold off;
xlim(ax_zoom, [94,98]);
ylim(ax_zoom, [0.01994,0.01999]);
box(ax_zoom,'on');
set(ax_zoom,'LineWidth',1,'FontName','Times New Roman','FontSize',10,'FontWeight','bold');
%% ----------------------------------------------------�����ɳ�����
figure(2);
plot(tk_type1,g1_type1,'r-','LineWidth',1);
hold on;
plot(tk_type1,g2_type1,'c-','LineWidth',1);
hold on;
plot(tk_type1_MRRB3,g1_type1_MRRB3,'b-','LineWidth',2);
hold on;
plot(tk_type1_MRRB3,g2_type1_MRRB3,'g-','LineWidth',2);
legend('$\gamma_n^{[1]}$-$\mathrm{MRRB2}$ I','$\gamma_n^{[2]}$-$\mathrm{MRRB2}$ I',...
            '$\gamma_n^{[1]}$-$\mathrm{MRRB3}$ I','$\gamma_n^{[2]}$-$\mathrm{MRRB3}$ I','interpreter','latex')
set(gca,'YLim',[-0.15 0.1])
set(gca,'LineWidth',1.5,'FontName','Times New Roman','FontSize',15,'FontWeight','bold');
xlabel('$\mathrm{Time}$','interpreter','latex','FontSize',25)
ylabel('$\gamma_n^{[1]}\;$or$\;\gamma_n^{[2]}$','interpreter','latex','FontSize',25)
%���ƾֲ��Ŵ���ͼ
ax_zoom=axes('Position',[0.26, 0.26, 0.3, 0.25]);
plot(tk_type1,g1_type1,'r-','LineWidth',1);
hold on;
plot(tk_type1,g2_type1,'c-','LineWidth',1);
hold on;
plot(tk_type1_MRRB3,g1_type1_MRRB3,'b-','LineWidth',2);
hold on;
plot(tk_type1_MRRB3,g2_type1_MRRB3,'g-','LineWidth',2);
xlim(ax_zoom, [94,98]);hold off;
ylim(ax_zoom, [-0.011,0.00975]);
box(ax_zoom,'on');
set(ax_zoom,'LineWidth',1,'FontName','Times New Roman','FontSize',10,'FontWeight','bold');
%% ----------------------------------------------------���Ƶ�������
figure(3);
plot(tk_type1,Iter_type1,'ro','LineWidth',1.5);
hold on;
plot(tk_type1_MRRB3,Iter_type1_MRRB3,'b+','LineWidth',1.5);
legend('$\mathrm{MRRB2}$ I','$\mathrm{MRRB3}$ I','interpreter','latex')
set(gca,'YLim',[0 12])
set(gca,'LineWidth',1.5,'FontName','Times New Roman','FontSize',15,'FontWeight','bold');
xlabel('$\mathrm{Time}$','interpreter','latex','FontSize',25)
ylabel('$N_{\mathrm{iter}}$','interpreter','latex','FontSize',25)
%% ----------------------------------------------------���ƾ���B
figure(4);
plot(tk_type1,detB_type1,'r-','LineWidth',1.5);
hold on;
plot(tk_type1_MRRB3,detB_type1_MRRB3,'b-','LineWidth',1.5);
legend('$\mathrm{MRRB2}$ I','$\mathrm{MRRB3}$ I','interpreter','latex')
set(gca,'YLim',[1*10^6 5*10^6])
set(gca,'LineWidth',1.5,'FontName','Times New Roman','FontSize',15,'FontWeight','bold');
xlabel('$\mathrm{Time}$','interpreter','latex','FontSize',25)
ylabel('$B_n^{\varepsilon}$','interpreter','latex','FontSize',25)
toc;