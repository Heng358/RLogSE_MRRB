clear;
clc;
close all;
tic;
%% ----------------------------------------------------�غ��Բ��Գߴ�
tau=1/50;
T=100;
%% ----------------------------------------------------�����㷨
[energy2,mass2,tk2]=RLogSE_RB2_conservation_1D(tau,T);
[energy3,mass3,tk3]=RLogSE_RB3_conservation_1D(tau,T);
%% ----------------------------------------------------��������������
RM2=abs(mass2-mass2(1))/abs(mass2(1));%RB2 ����
RM3=abs(mass3-mass3(1))/abs(mass3(1));%RB3 ����
%% ----------------------------------------------------��������������
RE2=abs(energy2-energy2(1))/abs(energy2(1));%RB2 ����
RE3=abs(energy3-energy3(1))/abs(energy3(1));%RB3 ����
%% ----------------------------------------------------��������������ͼ
figure(1);
semilogy(tk2,RM2,'r-','LineWidth',2);
hold on;
semilogy(tk3,RM3,'b-','LineWidth',2);
legend('$\mathrm{RB2}$','$\mathrm{RB3}$','Interpreter','Latex')
% set(gca,'XLim',[0 100])
% set(gca,'YLim',[10^(-16) 0.15*10^(-13)])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',17,'FontWeight','bold');
xlabel('$\mathrm{Time}$','Interpreter','Latex','FontSize',25);
ylabel('$RM_{n}$','Interpreter','Latex','FontSize',25);
%% ----------------------------------------------------��������������ͼ
figure(2);
semilogy(tk2,RE2,'r-','LineWidth',2);
hold on;
semilogy(tk3,RE3,'b-','LineWidth',2);
legend('$\mathrm{RB2}$','$\mathrm{RB3}$','Interpreter','Latex')
% set(gca,'XLim',[0 100])
% set(gca,'YLim',[10^(-16) 0.15*10^(-13)])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',17,'FontWeight','bold');
xlabel('$\mathrm{Time}$','Interpreter','Latex','FontSize',25);
ylabel('$RE_{n}$','Interpreter','Latex','FontSize',25);
toc;