clear;
clc;
close all;
tic;
%% ----------------------------------------------------�غ��Բ��Գߴ�
tau=1/50;
T=100;
%% ----------------------------------------------------�����㷨
[energy2_type1,mass2_type1,tk2_type1]=RLogSE_MRRB2_type1_conservation_1D(tau,T);
[energy2_type2,mass2_type2,tk2_type2]=RLogSE_MRRB2_type2_conservation_1D(tau,T);

[energy3_type1,mass3_type1,tk3_type1]=RLogSE_MRRB3_type1_conservation_1D(tau,T);
[energy3_type2,mass3_type2,tk3_type2]=RLogSE_MRRB3_type2_conservation_1D(tau,T);
%% ----------------------------------------------------��������������
RM2_type1=abs(mass2_type1-mass2_type1(1))/abs(mass2_type1(1));%MRRB2 I ����
RM2_type2=abs(mass2_type2-mass2_type2(1))/abs(mass2_type2(1));%MRRB2 II ����

RM3_type1=abs(mass3_type1-mass3_type1(1))/abs(mass3_type1(1));%MRRB3 I ����
RM3_type2=abs(mass3_type2-mass3_type2(1))/abs(mass3_type2(1));%MRRB3 II ����
%% ----------------------------------------------------��������������
RE2_type1=abs(energy2_type1-energy2_type1(1))/abs(energy2_type1(1));%MRRB2 I ����
RE2_type2=abs(energy2_type2-energy2_type2(1))/abs(energy2_type2(1));%MRRB2 II ����

RE3_type1=abs(energy3_type1-energy3_type1(1))/abs(energy3_type1(1));%MRRB3 I ����
RE3_type2=abs(energy3_type2-energy3_type2(1))/abs(energy3_type2(1));%MRRB3 II ����
%% ----------------------------------------------------��������������ͼ
figure(1);
semilogy(tk2_type1,RM2_type1,'r-','LineWidth',2);
hold on;
semilogy(tk3_type1,RM3_type1,'b-','LineWidth',2);
hold on;
semilogy(tk2_type2,RM2_type2,'g-.','LineWidth',2);
hold on;
semilogy(tk3_type2,RM3_type2,'m-.','LineWidth',2);
legend('$\mathrm{MRRB2}$ I','$\mathrm{MRRB3}$ I','$\mathrm{MRRB2}$ II','$\mathrm{MRRB3}$ II','Interpreter','Latex')
% set(gca,'XLim',[0 100])
% set(gca,'YLim',[10^(-16) 0.15*10^(-13)])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',17,'FontWeight','bold');
xlabel('$\mathrm{Time}$','Interpreter','Latex','FontSize',25);
ylabel('$RM_{n}$','Interpreter','Latex','FontSize',25);
%% ----------------------------------------------------��������������ͼ
figure(2);
semilogy(tk2_type1,RE2_type1,'r-','LineWidth',2);
hold on;
semilogy(tk3_type1,RE3_type1,'b-','LineWidth',2);
hold on;
semilogy(tk2_type2,RE2_type2,'g-.','LineWidth',2);
hold on;
semilogy(tk3_type2,RE3_type2,'m-.','LineWidth',2);
legend('$\mathrm{MRRB2}$ I','$\mathrm{MRRB3}$ I','$\mathrm{MRRB2}$ II','$\mathrm{MRRB3}$ II','Interpreter','Latex')
% set(gca,'XLim',[0 100])
% set(gca,'YLim',[10^(-16) 0.15*10^(-13)])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',17,'FontWeight','bold');
xlabel('$\mathrm{Time}$','Interpreter','Latex','FontSize',25);
ylabel('$RE_{n}$','Interpreter','Latex','FontSize',25);
toc;