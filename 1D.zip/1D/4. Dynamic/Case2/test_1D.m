clear;
clc;
close all;
tic;
%% ----------------------------------------------------����ѧ���Գߴ�
tau=0.001;
T=16;
%% ----------------------------------------------------�����㷨
[U1,U2,xk,tk]=RLogSE_MRRB2_type1_dynamics_case2_1D(tau,T);
%% ----------------------------------------------------���Ƶȸ���ͼ (case 1 �� case 2 ����)
figure(1);
[X,Y]=meshgrid(xk,tk);                                                                                                                                                                                                                                                                                                                          
pcolor(X',Y',U1);
shading interp;
colorbar;
colormap(jet);
set(gca,'XLim',[-40 40])
set(gca,'YLim',[0 16])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlabel('$x$','Interpreter','Latex','FontSize',25);
ylabel('$\mathrm{Time}$','Interpreter','Latex','FontSize',25);
% %% ----------------------------------------------------���� case 1 ����ʱ�̵�ͼ��
% figure(2);
% plot(xk,U2(:,6001),'b.','LineWidth',2);%t=6.0000
% hold on;
% plot(xk,U2(:,7451),'k:','LineWidth',2);%t=7.4500
% hold on;
% plot(xk,U2(:,11701),'r-','LineWidth',2);%t=11.7001
% legend('$t=6.0000$','$t=7.4500$','$t=11.7001$','Interpreter','Latex')
% set(gca,'XLim',[-20 20])
% set(gca,'YLim',[0 2])
% set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
% xlabel('$x$','Interpreter','Latex','FontSize',25);
% ylabel('$|u^{\epsilon}|$','Interpreter','Latex','FontSize',25);
%% =============================���� case 2 ����ʱ�̵�ͼ��
figure(2);
plot(xk,U2(:,831),'b.','LineWidth',2);%t=0.8300
hold on;
plot(xk,U2(:,1001),'k:','LineWidth',2);%t=1.0000
hold on;
plot(xk,U2(:,1351),'r-','LineWidth',2);%t=1.3500
legend('$t=0.8300$','$t=1.0000$','$t=1.3500$','Interpreter','Latex')
set(gca,'XLim',[-14 14])
set(gca,'YLim',[0 2])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlabel('$x$','Interpreter','Latex','FontSize',25);
ylabel('$|u^{\epsilon}|$','Interpreter','Latex','FontSize',25);
toc;