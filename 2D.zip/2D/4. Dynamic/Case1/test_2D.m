clear;
clc;
close all;
tic;
%% ----------------------------------------------------����ѧ���Գߴ�
tau=1/100;
T=100;
%% ----------------------------------------------------�����㷨
% [U,X,Y,tk]=RLogSE_MRRB2_type1_dynamics_case1_2D(tau,T);
%% ----------------------------------------------------���������
% save('RLogSE_MRRB2_type1_dynamics_case1_2D','U','X','Y','tk');
%% ----------------------------------------------------���ؼ�����
load('RLogSE_MRRB2_type1_dynamics_case1_2D.mat');
%% ----------------------------------------------------���� t = 0 ʱ��ͼ
figure(1);
pcolor(X,Y,U{1});
shading interp;
colorbar;
colormap(jet);
set(gca,'XLim',[-6 6])
set(gca,'YLim',[-6 6])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlabel('$x$','Interpreter','Latex','FontSize',25);
ylabel('$y$','Interpreter','Latex','FontSize',25);
% title('$t=0$','Interpreter','Latex','FontSize',25);
%% ----------------------------------------------------���� t = 10.0047 ʱ��ͼ
figure(2);
pcolor(X,Y,U{1000});
shading interp;
colorbar;
colormap(jet);
set(gca,'XLim',[-6 6])
set(gca,'YLim',[-6 6])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlabel('$x$','Interpreter','Latex','FontSize',25);
ylabel('$y$','Interpreter','Latex','FontSize',25);
% title('$t=10.0047$','Interpreter','Latex','FontSize',25);
%% ----------------------------------------------------���� t = 20.0249 ʱ��ͼ
figure(3);
pcolor(X,Y,U{2000});
shading interp;
colorbar;
colormap(jet);
set(gca,'XLim',[-6 6])
set(gca,'YLim',[-6 6])
set(gca,'LineWidth',1.5,'FontName','Times New Roman','FontSize',15,'FontWeight','bold');
xlabel('$x$','Interpreter','Latex','FontSize',25);
ylabel('$y$','Interpreter','Latex','FontSize',25);
% title('$t=20.0249$','Interpreter','Latex','FontSize',25);
%% ----------------------------------------------------���� t = 50.0277 ʱ��ͼ
figure(4);
pcolor(X,Y,U{5000});
shading interp;
colorbar;
colormap(jet);
set(gca,'XLim',[-6 6])
set(gca,'YLim',[-6 6])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlabel('$x$','Interpreter','Latex','FontSize',25);
ylabel('$y$','Interpreter','Latex','FontSize',25);
% title('$t=50.0277$','Interpreter','Latex','FontSize',25);
%% ----------------------------------------------------���� t = 70.0225 ʱ��ͼ
figure(5);
pcolor(X,Y,U{7000});
shading interp;
colorbar;
colormap(jet);
set(gca,'XLim',[-6 6])
set(gca,'YLim',[-6 6])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlabel('$x$','Interpreter','Latex','FontSize',25);
ylabel('$y$','Interpreter','Latex','FontSize',25);
% title('$t=70.0225$','Interpreter','Latex','FontSize',25);
%% ----------------------------------------------------���� t = 80.0230 ʱ��ͼ
figure(6);
pcolor(X,Y,U{8000});
shading interp;
colorbar;
colormap(jet);
set(gca,'XLim',[-6 6])
set(gca,'YLim',[-6 6])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlabel('$x$','Interpreter','Latex','FontSize',25);
ylabel('$y$','Interpreter','Latex','FontSize',25);
% title('$t=80.0230$','Interpreter','Latex','FontSize',25);
toc;