clear;
clc;
close all;
tic;
%% ----------------------------------------------------����ѧ���Գߴ�
tau=10^(-4);
T=1;
%% ----------------------------------------------------�����㷨
% [U,X,Y,tk]=RLogSE_MRRB2_type1_dynamics_case2_2D(tau,T);
%% ----------------------------------------------------���������
% save('RLogSE_MRRB2_type1_dynamics_case2_2D','U','X','Y','tk');
%% ----------------------------------------------------���ؼ�����
load('RLogSE_MRRB2_type1_dynamics_case2_2D.mat');
%% ----------------------------------------------------���� t = 0 ʱ��ͼ
figure(1);
pcolor(X,Y,U{1});
shading interp;
colorbar;
colormap(jet);
set(gca,'XLim',[-10 10])
set(gca,'YLim',[-10 10])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlabel('$x$','Interpreter','Latex','FontSize',25);
ylabel('$y$','Interpreter','Latex','FontSize',25);
% title('$t=0$','Interpreter','Latex','FontSize',25);
%% ----------------------------------------------------���� t = 0.2500 ʱ��ͼ
figure(2);
pcolor(X,Y,U{2501});
shading interp;
colorbar;
colormap(jet);
set(gca,'XLim',[-10 10])
set(gca,'YLim',[-10 10])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlabel('$x$','Interpreter','Latex','FontSize',25);
ylabel('$y$','Interpreter','Latex','FontSize',25);
% title('$t=0.2500$','Interpreter','Latex','FontSize',25);
%% ----------------------------------------------------���� t = 0.5000 ʱ��ͼ
figure(3);
pcolor(X,Y,U{5001});
shading interp;
colorbar;
colormap(jet);
set(gca,'XLim',[-10 10])
set(gca,'YLim',[-10 10])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlabel('$x$','Interpreter','Latex','FontSize',25);
ylabel('$y$','Interpreter','Latex','FontSize',25);
% title('$t=0.5000$','Interpreter','Latex','FontSize',25);
toc;