clear;
clc;
close all;
tic;
%% ----------------------------------------------------�غ��Բ��Գߴ�
tau=1/50;
T=100;
%% ----------------------------------------------------�����㷨
% [energy,mass,tk]=RLogSE_MRRB2_conservation_type1_2D(tau,T);
% [energy2,mass2,tk2]=RLogSE_MRRB2_conservation_type2_2D(tau,T);
% [energy_no,mass_no,tk_no]=RLogSE_RB2_conservation_2D(tau,T);
[energy3_type1,mass3_type1,tk3_type1]=RLogSE_MRRB3_type1_conservation_2D(tau,T);
[energy3_type2,mass3_type2,tk3_type2]=RLogSE_MRRB3_type2_conservation_2D(tau,T);
%% ----------------------------------------------------���������
save('RLogSE_MRRB3_conservation_2D_type1+type2.mat','energy3_type1','mass3_type1','tk3_type1','energy3_type2','mass3_type2','tk3_type2');
% save('RLogSE_MRRB2_conservation_2D_type1+type2.mat','energy','mass','tk','energy2','mass2','tk2','energy_no','mass_no','tk_no');
%% ----------------------------------------------------���ؼ�����
load('RLogSE_MRRB2_conservation_2D_type1+type2.mat');
%% ----------------------------------------------------��������������
RM=abs(mass-mass(1))/abs(mass(1));%MRRB2 I ����
RM2=abs(mass2-mass2(1))/abs(mass2(1));%MRRB2 II ����

RM3_type1=abs(mass3_type1-mass3_type1(1))/abs(mass3_type1(1));%MRRB3 I ����
RM3_type2=abs(mass3_type2-mass3_type2(1))/abs(mass3_type2(1));%MRRB3 II ����
%% ----------------------------------------------------��������������
RE=abs(energy-energy(1))/abs(energy(1));%MRRB2 I ����
RE2=abs(energy2-energy2(1))/abs(energy2(1));%MRRB2 II ����

RE3_type1=abs(energy3_type1-energy3_type1(1))/abs(energy3_type1(1));%MRRB3 I ����
RE3_type2=abs(energy3_type2-energy3_type2(1))/abs(energy3_type2(1));%MRRB3 II ����

% RM_no=abs(mass_no-mass_no(1))/abs(mass_no(1));%RB2 ����
% RE_no=abs(energy_no-energy_no(1))/abs(energy_no(1));%RB2 ����
%% ----------------------------------------------------��������������ͼ
figure(1);
semilogy(tk,RM,'r-','LineWidth',2);
hold on;
semilogy(tk3_type1,RM3_type1,'b-','LineWidth',2);
hold on;
semilogy(tk2,RM2,'g-.','LineWidth',2);
hold on;
semilogy(tk3_type2,RM3_type2,'m-.','LineWidth',2);
legend('$\mathrm{MRRB2}$ I','$\mathrm{MRRB3}$ I','$\mathrm{MRRB2}$ II','$\mathrm{MRRB3}$ II','Interpreter','Latex')
set(gca,'XLim',[0 100])
% set(gca,'YLim',[10^(-16) 10^(-1)])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',17,'FontWeight','bold');
xlabel('$\mathrm{Time}$','Interpreter','Latex','FontSize',25);
ylabel('$RM_{n}$','Interpreter','Latex','FontSize',25);
%% ----------------------------------------------------��������������ͼ
figure(2);
semilogy(tk,RE,'r-','LineWidth',2);
hold on;
semilogy(tk3_type1,RE3_type1,'b-','LineWidth',2);
hold on;
semilogy(tk2,RE2,'g-.','LineWidth',2);
hold on;
semilogy(tk3_type2,RE3_type2,'m-.','LineWidth',2);
legend('$\mathrm{MRRB2}$ I','$\mathrm{MRRB3}$ I','$\mathrm{MRRB2}$ II','$\mathrm{MRRB3}$ II','Interpreter','Latex')
set(gca,'XLim',[0 100])
% set(gca,'YLim',[10^(-16) 10^(-1)])
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',17,'FontWeight','bold');
xlabel('$\mathrm{Time}$','Interpreter','Latex','FontSize',25);
ylabel('$RE_{n}$','Interpreter','Latex','FontSize',25);
toc;