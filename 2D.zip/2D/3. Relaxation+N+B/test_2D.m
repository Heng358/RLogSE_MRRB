clear;
clc;
close all;
tic;
%% ----------------------------------------------------���Գߴ�
tau=1/50;
T=100;
%% ----------------------------------------------------�����㷨
% [g1_type1,g2_type1,relaxation_tau_type1,detB_type1,tk_type1,Iter_type1]=relaxation_factors_tau_B_N_compare_type1_2D(tau,T);
% [g1_type2,g2_type2,relaxation_tau_type2,detB_type2,tk_type2,Iter_type2]=relaxation_factors_tau_B_N_compare_type2_2D(tau,T);
[g1_MRRB3_type1,g2_MRRB3_type1,relaxation_tau_MRRB3_type1,detB_MRRB3_type1,tk_MRRB3_type1,...
    Iter_MRRB3_type1]=MRRB3_relaxation_factors_tau_B_N_compare_type1_2D(tau,T);
[g1_MRRB3_type2,g2_MRRB3_type2,relaxation_tau_MRRB3_type2,detB_MRRB3_type2,tk_MRRB3_type2,...
    Iter_MRRB3_type2]=MRRB3_relaxation_factors_tau_B_N_compare_type2_2D(tau,T);
%% ���������
% save('relaxation_factors_tau_B_N_compare_type1_2D','g1_type1','g2_type1','relaxation_tau_type1','detB_type1','tk_type1','Iter_type1');
% save('relaxation_factors_tau_B_N_compare_type2_2D','g1_type2','g2_type2','relaxation_tau_type2','detB_type2','tk_type2','Iter_type2');
save('MRRB3_relaxation_factors_tau_B_N_compare_type1_2D','g1_MRRB3_type1','g2_MRRB3_type1',...
    'relaxation_tau_MRRB3_type1','detB_MRRB3_type1','tk_MRRB3_type1','Iter_MRRB3_type1');
save('MRRB3_relaxation_factors_tau_B_N_compare_type2_2D','g1_MRRB3_type2','g2_MRRB3_type2',...
    'relaxation_tau_MRRB3_type2','detB_MRRB3_type2','tk_MRRB3_type2','Iter_MRRB3_type2');
%% ���ؼ�����
load('relaxation_factors_tau_B_N_compare_type1_2D');
load('relaxation_factors_tau_B_N_compare_type2_2D');
%% ----------------------------------------------------�����ɳ�ʱ�䲽���ݻ�ͼ
figure(1);
plot(tk_type1,relaxation_tau_type1,'r-','LineWidth',1.5);
hold on;
plot(tk_MRRB3_type1,relaxation_tau_MRRB3_type1,'b-','LineWidth',1.5);
hold on;
plot(0:0.1:100,tau*ones(1,size(0:0.1:100,2)),'k:','LineWidth',2);
legend('$\mathrm{MRRB2}$ I','$\mathrm{MRRB3}$ I','$\tau=0.02$','interpreter','latex')
set(gca,'XLim',[0 100])
set(gca,'YLim',[0.0196 0.0201])
set(gca,'LineWidth',1.5,'FontName','Times New Roman','FontSize',15,'FontWeight','bold');
xlabel('$\mathrm{Time}$','interpreter','latex','FontSize',25)
ylabel('$\tau_{\gamma}$','interpreter','latex','FontSize',25)
%���ƾֲ��Ŵ���ͼ
ax_zoom=axes('Position',[0.3, 0.3, 0.3, 0.25]);
plot(tk_type1,relaxation_tau_type1,'r-','LineWidth',1.5, 'Parent',ax_zoom);
hold on;
plot(tk_MRRB3_type1,relaxation_tau_MRRB3_type1,'b-','LineWidth',1.5, 'Parent',ax_zoom);
hold on;
plot(0:0.1:100,tau*ones(1,size(0:0.1:100,2)),'k:','LineWidth',2, 'Parent',ax_zoom);hold off;
xlim(ax_zoom, [0,10]);
ylim(ax_zoom, [0.01998,0.02002]);
box(ax_zoom,'on');
set(ax_zoom,'LineWidth',1,'FontName','Times New Roman','FontSize',10,'FontWeight','bold');
%% ----------------------------------------------------�����ɳ������ݻ�ͼ
figure(2);
plot(tk_type1,g1_type1,'r-','LineWidth',1);
hold on;
plot(tk_type1,g2_type1,'c-','LineWidth',1);
hold on;
plot(tk_MRRB3_type1,g1_MRRB3_type1,'b-','LineWidth',2);
hold on;
plot(tk_MRRB3_type1,g2_MRRB3_type1,'g-','LineWidth',2);
legend('$\gamma_n^{[1]}$-$\mathrm{MRRB2}$ I','$\gamma_n^{[2]}$-$\mathrm{MRRB2}$ I',...
            '$\gamma_n^{[1]}$-$\mathrm{MRRB3}$ I','$\gamma_n^{[2]}$-$\mathrm{MRRB3}$ I','interpreter','latex')
set(gca,'XLim',[0 100])
set(gca,'YLim',[-0.15 0.1])
set(gca,'LineWidth',1.5,'FontName','Times New Roman','FontSize',15,'FontWeight','bold');
xlabel('$\mathrm{Time}$','interpreter','latex','FontSize',25)
ylabel('$\gamma_n^{[1]}\;$or$\;\gamma_n^{[2]}$','interpreter','latex','FontSize',25)
%���ƾֲ��Ŵ���ͼ
ax_zoom=axes('Position',[0.26, 0.26, 0.3, 0.25]);
plot(tk_type1,g1_type1,'r-','LineWidth',1);
hold on;
plot(tk_type1,g2_type1,'c-','LineWidth',1);
hold on;
plot(tk_MRRB3_type1,g1_MRRB3_type1,'b-','LineWidth',2);
hold on;
plot(tk_MRRB3_type1,g2_MRRB3_type1,'g-','LineWidth',2);
xlim(ax_zoom, [94,98]);hold off;
xlim(ax_zoom, [0,10]);
ylim(ax_zoom, [-0.015,0.015]);
box(ax_zoom,'on');
set(ax_zoom,'LineWidth',1,'FontName','Times New Roman','FontSize',10,'FontWeight','bold');
%% ----------------------------------------------------���ƾ��� B �ݻ�ͼ
figure(3);
plot(tk_type1,detB_type1,'r-','LineWidth',1.5);
hold on;
plot(tk_MRRB3_type1,detB_MRRB3_type1,'b-','LineWidth',1.5);
legend('$\mathrm{MRRB2}$ I','$\mathrm{MRRB3}$ I','interpreter','latex')
set(gca,'XLim',[0 100])
set(gca,'YLim',[0.6*10^8 1.2*10^8])
set(gca,'LineWidth',1.5,'FontName','Times New Roman','FontSize',15,'FontWeight','bold');
xlabel('$\mathrm{Time}$','interpreter','latex','FontSize',25)
ylabel('$B_n^{\varepsilon}$','interpreter','latex','FontSize',25)
%% ----------------------------------------------------���Ƶ�������ͼ
figure(4);
plot(tk_type1,Iter_type1,'ro','LineWidth',1.5);
hold on;
plot(tk_MRRB3_type1,Iter_MRRB3_type1,'b+','LineWidth',1.5);
legend('$\mathrm{MRRB2}$ I','$\mathrm{MRRB3}$ I','interpreter','latex')
set(gca,'YLim',[0 12])
set(gca,'LineWidth',1.5,'FontName','Times New Roman','FontSize',15,'FontWeight','bold');
xlabel('$\mathrm{Time}$','interpreter','latex','FontSize',25)
ylabel('$N_{\mathrm{iter}}$','interpreter','latex','FontSize',25)
toc;