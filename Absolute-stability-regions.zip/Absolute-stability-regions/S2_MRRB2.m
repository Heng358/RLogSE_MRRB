clc;
clear;
close all;
tic;
%%
x=linspace(-10,10,1000);
y=linspace(-10,10,1000);
[X,Y]=meshgrid(x,y);
Z=X+1i*Y;

B=[0.5 0.5];b=[1 0];

r11=-0.0785;       r12=0.059;
Rz1=abs(1+Z.*((-(2*(r11/2+r12+1/2))./(Z-2))-((2*(r11/2+1/2))./(Z-2))));
Q1=norm((1+r11)*B+r12*b);   q1=(1+r11)*B+r12*b;           


r110=0.0163;       r120=-0.0358;
Rz10=abs(1+Z.*((-(2*(r110/2+r120+1/2))./(Z-2))-((2*(r110/2+1/2))./(Z-2))));


r21=-0.0292;       r22=0.0219;
Rz2=abs(1+Z.*((-(2*(r21/2+r22+1/2))./(Z-2))-((2*(r21/2+1/2))./(Z-2))));
Q2=norm((1+r21)*B+r22*b);      q2=(1+r21)*B+r22*b;        

r31=8.877234972969175e-04;       r32=-8.877234972969175e-04;
% r32=-8.872876263263405e-04;
Rz3=abs(1+Z.*((-(2*(r31/2+r32+1/2))./(Z-2))-((2*(r31/2+1/2))./(Z-2))));
Q3=norm((1+r31)*B+r32*b);     q3= (1+r31)*B+r32*b;        

r41=0.0172;       r42=-0.0135;
Rz4=abs(1+Z.*((-(2*(r41/2+r42+1/2))./(Z-2))-((2*(r41/2+1/2))./(Z-2))));
Q4=norm((1+r41)*B+r42*b);   q4=(1+r41)*B+r42*b;     

r410=-0.0321;       r420=0.0358;
Rz40=abs(1+Z.*((-(2*(r410/2+r420+1/2))./(Z-2))-((2*(r410/2+1/2))./(Z-2))));
%%
figure(1);
contourf(X,Y,Rz1<=1,[0.5,1.5],'FaceColor',[0.4 0.6 0.8],'EdgeColor','none');
hold on;
contour(X,Y,Rz1,[1,1],'LineWidth',1,'Color','r','LineStyle','-');
axis equal;
xlabel('$\mathrm{Re}(z)$','Interpreter','Latex','FontSize',25);
ylabel('$\mathrm{Im}(z)$','Interpreter','Latex','FontSize',25);
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlim([-10 10]);
ylim([-10 10]);
xax=get(gca,'XLim');
yax=get(gca,'YLim');
hold on;
plot([0 0],yax,'k:','LineWidth',1);
plot(xax,[0 0],'k:','LineWidth',1);
% title('$\gamma^{[1]}=-0.0785,\;\gamma^{[2]}=0.0590$','Interpreter','Latex','FontSize',25);
%%
figure(2);
contourf(X,Y,Rz10<=1,[0.5,1.5],'FaceColor',[0.4 0.6 0.8],'EdgeColor','none');
hold on;
contour(X,Y,Rz10,[1,1],'LineWidth',1,'Color','r','LineStyle','-');
axis equal;
xlabel('$\mathrm{Re}(z)$','Interpreter','Latex','FontSize',25);
ylabel('$\mathrm{Im}(z)$','Interpreter','Latex','FontSize',25);
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlim([-10 10]);
ylim([-10 10]);
xax=get(gca,'XLim');
yax=get(gca,'YLim');
hold on;
plot([0 0],yax,'k:','LineWidth',1);
plot(xax,[0 0],'k:','LineWidth',1);
%%
figure(3);
contourf(X,Y,Rz2<=1,[0.5,1.5],'FaceColor',[0.4 0.6 0.8],'EdgeColor','none');
hold on;
contour(X,Y,Rz2,[1,1],'LineWidth',1,'Color','r','LineStyle','-');
axis equal;
xlabel('$\mathrm{Re}(z)$','Interpreter','Latex','FontSize',25);
ylabel('$\mathrm{Im}(z)$','Interpreter','Latex','FontSize',25);
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlim([-10 10]);
ylim([-10 10]);
xax=get(gca,'XLim');
yax=get(gca,'YLim');
hold on;
plot([0 0],yax,'k:','LineWidth',1);
plot(xax,[0 0],'k:','LineWidth',1);
% title('$\gamma^{[1]}=-0.0292,\;\gamma^{[2]}=0.0219$','Interpreter','Latex','FontSize',25);
%%
figure(4);
contourf(X,Y,Rz3<=1,[0.5,1.5],'FaceColor',[0.4 0.6 0.8],'EdgeColor','none');
hold on;
contour(X,Y,Rz3,[1,1],'LineWidth',1,'Color','r','LineStyle','-');
axis equal;
xlabel('$\mathrm{Re}(z)$','Interpreter','Latex','FontSize',25);
ylabel('$\mathrm{Im}(z)$','Interpreter','Latex','FontSize',25);
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlim([-10 10]);
ylim([-10 10]);
xax=get(gca,'XLim');
yax=get(gca,'YLim');
hold on;
plot([0 0],yax,'k:','LineWidth',1);
plot(xax,[0 0],'k:','LineWidth',1);
% title('$\gamma^{[1]}=8.8772e-04,\;\gamma^{[2]}=-8.8728e-04$','Interpreter','Latex','FontSize',25);
%% 
figure(5);
contourf(X,Y,Rz4<=1,[0.5,1.5],'FaceColor',[0.4 0.6 0.8],'EdgeColor','none');
hold on;
contour(X,Y,Rz4,[1,1],'LineWidth',1,'Color','r','LineStyle','-');
axis equal;
xlabel('$\mathrm{Re}(z)$','Interpreter','Latex','FontSize',25);
ylabel('$\mathrm{Im}(z)$','Interpreter','Latex','FontSize',25);
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlim([-10 10]);
ylim([-10 10]);
xax=get(gca,'XLim');
yax=get(gca,'YLim');
hold on;
plot([0 0],yax,'k:','LineWidth',1);
plot(xax,[0 0],'k:','LineWidth',1);
% title('$\gamma^{[1]}=0.0172,\;\gamma^{[2]}=-0.0135$','Interpreter','Latex','FontSize',25);
%% 
figure(6);
contourf(X,Y,Rz40<=1,[0.5,1.5],'FaceColor',[0.4 0.6 0.8],'EdgeColor','none');
hold on;
contour(X,Y,Rz40,[1,1],'LineWidth',1,'Color','r','LineStyle','-');
axis equal;
xlabel('$\mathrm{Re}(z)$','Interpreter','Latex','FontSize',25);
ylabel('$\mathrm{Im}(z)$','Interpreter','Latex','FontSize',25);
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',20,'FontWeight','bold');
xlim([-10 10]);
ylim([-10 10]);
xax=get(gca,'XLim');
yax=get(gca,'YLim');
hold on;
plot([0 0],yax,'k:','LineWidth',1);
plot(xax,[0 0],'k:','LineWidth',1);

toc;