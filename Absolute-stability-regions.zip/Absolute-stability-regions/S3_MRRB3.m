clc;
clear;
close all;
tic;
%%
x=linspace(-10,15,1000);
y=linspace(-15,15,1000);
[X,Y]=meshgrid(x,y);
Z=X+1i*Y;
%% ----------------------------------------------------3 �� 3 �� Rosenbrock ����ϵ�� (ROS3Pw)
beta=0.78867513459481287; 
A=[0 0 0;1.5773502691896257 0 0;0.5 0 0];
B=[beta 0 0;-1.5773502691896257 beta 0;-0.67075317547305480 -0.17075317547305482 beta];       
b1=[0.10566243270259355 0.049038105676657971 0.84529946162074843]';
b2=[1/3 1/3 1/3]';
%%
r1=-0.0785;       r2=0.059;
B1=(1+r1)*b1(1)+r2*b2(1);
B2=(1+r1)*b1(2)+r2*b2(2);
B3=(1+r1)*b1(3)+r2*b2(3);
f=1+Z.*(B1*(1./(1-Z*beta))+B2*(((Z*(A(2,1)+B(2,1)))./((1-Z*beta).^2))+(1./(1-Z*beta)))+...
    B3*(((Z.^2*(A(2,1)+B(2,1))*(A(3,2)+B(3,2)))./((1-Z*beta).^3))+...
    ((Z*(A(3,1)+B(3,1)+A(3,2)+B(3,2)))./((1-Z*beta).^2))+(1./(1-Z*beta))));
F=1+(((Z)./(1-Z*beta))*(1+r1+r2))+(((Z.^2)./((1-Z*beta).^2))*(A(3,1)+B(3,1)+A(3,2)+B(3,2))*((1+r1)*b1(3)+r2*(b2(3))));
R1=abs(F);
%%
r1=-0.0292;       r2=0.0219;
B1=(1+r1)*b1(1)+r2*b2(1);
B2=(1+r1)*b1(2)+r2*b2(2);
B3=(1+r1)*b1(3)+r2*b2(3);
f=1+Z.*(B1*(1./(1-Z*beta))+B2*(((Z*(A(2,1)+B(2,1)))./((1-Z*beta).^2))+(1./(1-Z*beta)))+...
    B3*(((Z.^2*(A(2,1)+B(2,1))*(A(3,2)+B(3,2)))./((1-Z*beta).^3))+...
    ((Z*(A(3,1)+B(3,1)+A(3,2)+B(3,2)))./((1-Z*beta).^2))+(1./(1-Z*beta))));
R2=abs(f);
%%
r1=8.877234972969175e-04;       r2=-8.872876263263405e-04;
B1=(1+r1)*b1(1)+r2*b2(1);
B2=(1+r1)*b1(2)+r2*b2(2);
B3=(1+r1)*b1(3)+r2*b2(3);
f=1+Z.*(B1*(1./(1-Z*beta))+B2*(((Z*(A(2,1)+B(2,1)))./((1-Z*beta).^2))+(1./(1-Z*beta)))+...
    B3*(((Z.^2*(A(2,1)+B(2,1))*(A(3,2)+B(3,2)))./((1-Z*beta).^3))+...
    ((Z*(A(3,1)+B(3,1)+A(3,2)+B(3,2)))./((1-Z*beta).^2))+(1./(1-Z*beta))));
R3=abs(f);
%%
r1=0.0172;       r2=-0.0135;
B1=(1+r1)*b1(1)+r2*b2(1);
B2=(1+r1)*b1(2)+r2*b2(2);
B3=(1+r1)*b1(3)+r2*b2(3);
f=1+Z.*(B1*(1./(1-Z*beta))+B2*(((Z*(A(2,1)+B(2,1)))./((1-Z*beta).^2))+(1./(1-Z*beta)))+...
    B3*(((Z.^2*(A(2,1)+B(2,1))*(A(3,2)+B(3,2)))./((1-Z*beta).^3))+...
    ((Z*(A(3,1)+B(3,1)+A(3,2)+B(3,2)))./((1-Z*beta).^2))+(1./(1-Z*beta))));
R4=abs(f);
%%
figure(1);
contourf(X,Y,R4<=1,[1,1],'FaceColor',[0.4 0.6 0.8],'EdgeColor','none','handleVisibility','off');
hold on;
contour(X,Y,R1,[1,1],'LineWidth',2,'Color','m','LineStyle','-.');
hold on;
contour(X,Y,R2,[1,1],'LineWidth',2,'Color','g','LineStyle','-.');
hold on;
contour(X,Y,R3,[1,1],'LineWidth',2,'Color','b','LineStyle','-.');
hold on;
contour(X,Y,R4,[1,1],'LineWidth',2,'Color','r','LineStyle','-.');
legend('$\gamma^{[1]}=-0.0785,\;\gamma^{[2]}=0.0590$','$\gamma^{[1]}=-0.0292,\;\gamma^{[2]}=0.0219$',...
    '$\gamma^{[1]}=8.8772e-04,\;\gamma^{[2]}=-8.8728e-04$',...
    '$\gamma^{[1]}=0.0172,\;\gamma^{[2]}=-0.0135$','Interpreter','Latex','FontSize',25);
xlabel('$\mathrm{Re}(z)$','Interpreter','Latex','FontSize',35);
ylabel('$\mathrm{Im}(z)$','Interpreter','Latex','FontSize',35);
set(gca,'LineWidth',2,'FontName','Times New Roman','FontSize',30,'FontWeight','bold');
xlim([-10 15]);
ylim([-10 15]);
xax=get(gca,'XLim');
yax=get(gca,'YLim');
hold on;
plot([0 0],yax,'k:','LineWidth',1,'handleVisibility','off');
plot(xax,[0 0],'k:','LineWidth',1,'handleVisibility','off');
axis equal;
toc;